from django.contrib import admin
from doubt.models import Doubt, DoubtAnswer
# Register your models here.


admin.site.register(Doubt)
admin.site.register(DoubtAnswer)
